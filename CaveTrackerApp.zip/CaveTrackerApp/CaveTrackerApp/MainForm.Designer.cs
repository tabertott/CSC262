﻿namespace CaveTrackerApp
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblHeader = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.lblLocation = new System.Windows.Forms.Label();
            this.txtLocation = new System.Windows.Forms.TextBox();
            this.lblDepth = new System.Windows.Forms.Label();
            this.txtDepth = new System.Windows.Forms.TextBox();
            this.lblDifficulty = new System.Windows.Forms.Label();
            this.cmbDifficulty = new System.Windows.Forms.ComboBox();
            this.chkIsExplored = new System.Windows.Forms.CheckBox();
            this.btnAddCave = new System.Windows.Forms.Button();
            this.lstCaves = new System.Windows.Forms.ListBox();
            this.lblListHeader = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblHeader
            // 
            this.lblHeader.AutoSize = true;
            this.lblHeader.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblHeader.Location = new System.Drawing.Point(17, 17);
            this.lblHeader.Name = "lblHeader";
            this.lblHeader.Size = new System.Drawing.Size(207, 21);
            this.lblHeader.TabIndex = 12;
            this.lblHeader.Text = "Enter Cave System Details";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(17, 52);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(66, 13);
            this.lblName.TabIndex = 11;
            this.lblName.Text = "Cave Name:";
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(103, 49);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(155, 20);
            this.txtName.TabIndex = 10;
            // 
            // lblLocation
            // 
            this.lblLocation.AutoSize = true;
            this.lblLocation.Location = new System.Drawing.Point(17, 87);
            this.lblLocation.Name = "lblLocation";
            this.lblLocation.Size = new System.Drawing.Size(51, 13);
            this.lblLocation.TabIndex = 9;
            this.lblLocation.Text = "Location:";
            // 
            // txtLocation
            // 
            this.txtLocation.Location = new System.Drawing.Point(103, 84);
            this.txtLocation.Name = "txtLocation";
            this.txtLocation.Size = new System.Drawing.Size(155, 20);
            this.txtLocation.TabIndex = 8;
            // 
            // lblDepth
            // 
            this.lblDepth.AutoSize = true;
            this.lblDepth.Location = new System.Drawing.Point(17, 121);
            this.lblDepth.Name = "lblDepth";
            this.lblDepth.Size = new System.Drawing.Size(54, 13);
            this.lblDepth.TabIndex = 7;
            this.lblDepth.Text = "Depth (ft):";
            // 
            // txtDepth
            // 
            this.txtDepth.Location = new System.Drawing.Point(103, 119);
            this.txtDepth.Name = "txtDepth";
            this.txtDepth.Size = new System.Drawing.Size(155, 20);
            this.txtDepth.TabIndex = 6;
            // 
            // lblDifficulty
            // 
            this.lblDifficulty.AutoSize = true;
            this.lblDifficulty.Location = new System.Drawing.Point(17, 156);
            this.lblDifficulty.Name = "lblDifficulty";
            this.lblDifficulty.Size = new System.Drawing.Size(50, 13);
            this.lblDifficulty.TabIndex = 5;
            this.lblDifficulty.Text = "Difficulty:";
            // 
            // cmbDifficulty
            // 
            this.cmbDifficulty.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbDifficulty.Location = new System.Drawing.Point(103, 153);
            this.cmbDifficulty.Name = "cmbDifficulty";
            this.cmbDifficulty.Size = new System.Drawing.Size(155, 21);
            this.cmbDifficulty.TabIndex = 4;
            // 
            // chkIsExplored
            // 
            this.chkIsExplored.AutoSize = true;
            this.chkIsExplored.Location = new System.Drawing.Point(103, 191);
            this.chkIsExplored.Name = "chkIsExplored";
            this.chkIsExplored.Size = new System.Drawing.Size(91, 17);
            this.chkIsExplored.TabIndex = 3;
            this.chkIsExplored.Text = "Fully Explored";
            this.chkIsExplored.UseVisualStyleBackColor = true;
            // 
            // btnAddCave
            // 
            this.btnAddCave.Location = new System.Drawing.Point(17, 225);
            this.btnAddCave.Name = "btnAddCave";
            this.btnAddCave.Size = new System.Drawing.Size(240, 30);
            this.btnAddCave.TabIndex = 2;
            this.btnAddCave.Text = "Log Cave Entry";
            this.btnAddCave.UseVisualStyleBackColor = true;
            this.btnAddCave.Click += new System.EventHandler(this.btnAddCave_Click);
            // 
            // lstCaves
            // 
            this.lstCaves.FormattingEnabled = true;
            this.lstCaves.Location = new System.Drawing.Point(291, 49);
            this.lstCaves.Name = "lstCaves";
            this.lstCaves.Size = new System.Drawing.Size(626, 199);
            this.lstCaves.TabIndex = 1;
            // 
            // lblListHeader
            // 
            this.lblListHeader.AutoSize = true;
            this.lblListHeader.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblListHeader.Location = new System.Drawing.Point(291, 17);
            this.lblListHeader.Name = "lblListHeader";
            this.lblListHeader.Size = new System.Drawing.Size(133, 21);
            this.lblListHeader.TabIndex = 0;
            this.lblListHeader.Text = "Logged Systems";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(944, 283);
            this.Controls.Add(this.lblListHeader);
            this.Controls.Add(this.lstCaves);
            this.Controls.Add(this.btnAddCave);
            this.Controls.Add(this.chkIsExplored);
            this.Controls.Add(this.cmbDifficulty);
            this.Controls.Add(this.lblDifficulty);
            this.Controls.Add(this.txtDepth);
            this.Controls.Add(this.lblDepth);
            this.Controls.Add(this.txtLocation);
            this.Controls.Add(this.lblLocation);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.lblHeader);
            this.Name = "MainForm";
            this.Text = "Cave Tracker Console";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private System.Windows.Forms.Label lblHeader;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label lblLocation;
        private System.Windows.Forms.TextBox txtLocation;
        private System.Windows.Forms.Label lblDepth;
        private System.Windows.Forms.TextBox txtDepth;
        private System.Windows.Forms.Label lblDifficulty;
        private System.Windows.Forms.ComboBox cmbDifficulty;
        private System.Windows.Forms.CheckBox chkIsExplored;
        private System.Windows.Forms.Button btnAddCave;
        private System.Windows.Forms.ListBox lstCaves;
        private System.Windows.Forms.Label lblListHeader;
    }
}