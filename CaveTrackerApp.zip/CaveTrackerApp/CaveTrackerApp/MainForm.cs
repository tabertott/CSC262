﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Xml.Linq;

namespace CaveTrackerApp
{
    public partial class MainForm : Form
    {
        // A collection list to store all created Cave objects in memory
        private List<Cave> caveDatabase = new List<Cave>();

        public MainForm()
        {
            InitializeComponent();
            InitializeDifficultyDropdown();
        }

        // Populates the dropdown menu with difficulty options
        private void InitializeDifficultyDropdown()
        {
            cmbDifficulty.Items.Add("Beginner");
            cmbDifficulty.Items.Add("Intermediate");
            cmbDifficulty.Items.Add("Expert");
            cmbDifficulty.Items.Add("Technical/Gear Required");
            cmbDifficulty.SelectedIndex = 0; // Sets a default value
        }

        // Event handler for the 'Log Cave' button
        private void btnAddCave_Click(object sender, EventArgs e)
        {
            // Input Validation: Ensures strings are not empty and depth is a valid integer
            if (string.IsNullOrWhiteSpace(txtName.Text) || string.IsNullOrWhiteSpace(txtLocation.Text))
            {
                MessageBox.Show("Please provide both a Name and Location for the cave.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return; // Exits the method early to prevent bad data entry
            }

            // TryParse prevents the program from crashing if the user enters text in the depth field
            if (!int.TryParse(txtDepth.Text, out int parsedDepth) || parsedDepth < 0)
            {
                MessageBox.Show("Please enter a valid positive number for the cave depth.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Object Instantiation: Creates a new Cave object using the validated inputs
            Cave newCave = new Cave(
                txtName.Text,
                txtLocation.Text,
                parsedDepth,
                chkIsExplored.Checked,
                cmbDifficulty.SelectedItem.ToString()
            );

            // Adds the new object to our tracking list
            caveDatabase.Add(newCave);

            // Updates the UI to show the newly created object
            RefreshCaveList();
            ClearInputFields();
        }

        // Clears the display and repopulates it by calling the GetCaveSummary method on each object
        private void RefreshCaveList()
        {
            lstCaves.Items.Clear();
            foreach (Cave cave in caveDatabase)
            {
                // Appends the estimated descent time calculated by the second method
                string displayString = $"{cave.GetCaveSummary()} [Est. Descent: {cave.CalculateEstimatedDescentHours()} hrs]";
                lstCaves.Items.Add(displayString);
            }
        }

        // Resets the form inputs to their default state after a successful entry
        private void ClearInputFields()
        {
            txtName.Clear();
            txtLocation.Clear();
            txtDepth.Clear();
            chkIsExplored.Checked = false;
            cmbDifficulty.SelectedIndex = 0;
            txtName.Focus(); // Returns the cursor to the first box for easy sequential entry
        }
    }
}