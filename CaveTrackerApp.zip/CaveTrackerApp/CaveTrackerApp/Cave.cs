﻿using System;

namespace CaveTrackerApp
{
    public class Cave
    {
        // Property 1: The designated name of the cave system
        public string Name { get; set; }

        // Property 2: The geographical region or state where the cave is located
        public string Location { get; set; }

        // Property 3: The maximum known depth of the cave in feet
        public int DepthInFeet { get; set; }

        // Property 4: A true/false flag indicating if the cave has been fully mapped
        public bool IsFullyExplored { get; set; }

        // Property 5: The technical difficulty level (e.g., Beginner, Intermediate, Expert)
        public string DifficultyLevel { get; set; }

        // Constructor: Initializes a new instance of the Cave object with provided values
        public Cave(string name, string location, int depthInFeet, bool isFullyExplored, string difficultyLevel)
        {
            Name = name;
            Location = location;
            DepthInFeet = depthInFeet;
            IsFullyExplored = isFullyExplored;
            DifficultyLevel = difficultyLevel;
        }

        // Method 1: Generates a formatted summary string of the cave's attributes for UI display
        public string GetCaveSummary()
        {
            string explorationStatus = IsFullyExplored ? "Fully Explored" : "Partially Explored";
            return $"{Name} ({Location}) - {DepthInFeet}ft Deep | {DifficultyLevel} | {explorationStatus}";
        }

        // Method 2: Calculates an estimated descent time based on depth (assuming 20 feet per minute average)
        public double CalculateEstimatedDescentHours()
        {
            // Prevents division by zero or negative time calculations
            if (DepthInFeet <= 0) return 0;

            double minutes = DepthInFeet / 20.0;
            return Math.Round(minutes / 60.0, 2);
        }
    }
}