﻿namespace AdvancedCaveTracker
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.cmbCaveType = new System.Windows.Forms.ComboBox();
            this.lblType = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.lblName = new System.Windows.Forms.Label();
            this.txtLocation = new System.Windows.Forms.TextBox();
            this.lblLocation = new System.Windows.Forms.Label();
            this.txtDepth = new System.Windows.Forms.TextBox();
            this.lblDepth = new System.Windows.Forms.Label();
            this.grpSpecialAttrs = new System.Windows.Forms.GroupBox();
            this.txtAttr3 = new System.Windows.Forms.TextBox();
            this.lblAttr3 = new System.Windows.Forms.Label();
            this.txtAttr2 = new System.Windows.Forms.TextBox();
            this.lblAttr2 = new System.Windows.Forms.Label();
            this.txtAttr1 = new System.Windows.Forms.TextBox();
            this.lblAttr1 = new System.Windows.Forms.Label();
            this.btnAdd = new System.Windows.Forms.Button();
            this.lstCaves = new System.Windows.Forms.ListBox();
            this.cmbViewMode = new System.Windows.Forms.ComboBox();
            this.lblViewMode = new System.Windows.Forms.Label();
            this.grpSpecialAttrs.SuspendLayout();
            this.SuspendLayout();

            // cmbCaveType
            this.cmbCaveType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCaveType.FormattingEnabled = true;
            this.cmbCaveType.Items.AddRange(new object[] { "Standard Cave", "Underwater Cave", "Ice Cave" });
            this.cmbCaveType.Location = new System.Drawing.Point(120, 20);
            this.cmbCaveType.Name = "cmbCaveType";
            this.cmbCaveType.Size = new System.Drawing.Size(150, 23);
            this.cmbCaveType.SelectedIndexChanged += new System.EventHandler(this.cmbCaveType_SelectedIndexChanged);

            // lblType
            this.lblType.AutoSize = true;
            this.lblType.Location = new System.Drawing.Point(20, 23);
            this.lblType.Name = "lblType";
            this.lblType.Size = new System.Drawing.Size(63, 15);
            this.lblType.Text = "Cave Type:";

            // txtName & lblName
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(20, 63);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(42, 15);
            this.lblName.Text = "Name:";
            this.txtName.Location = new System.Drawing.Point(120, 60);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(150, 23);

            // txtLocation & lblLocation
            this.lblLocation.AutoSize = true;
            this.lblLocation.Location = new System.Drawing.Point(20, 103);
            this.lblLocation.Name = "lblLocation";
            this.lblLocation.Size = new System.Drawing.Size(56, 15);
            this.lblLocation.Text = "Location:";
            this.txtLocation.Location = new System.Drawing.Point(120, 100);
            this.txtLocation.Name = "txtLocation";
            this.txtLocation.Size = new System.Drawing.Size(150, 23);

            // txtDepth & lblDepth
            this.lblDepth.AutoSize = true;
            this.lblDepth.Location = new System.Drawing.Point(20, 143);
            this.lblDepth.Name = "lblDepth";
            this.lblDepth.Size = new System.Drawing.Size(62, 15);
            this.lblDepth.Text = "Depth (ft):";
            this.txtDepth.Location = new System.Drawing.Point(120, 140);
            this.txtDepth.Name = "txtDepth";
            this.txtDepth.Size = new System.Drawing.Size(150, 23);

            // grpSpecialAttrs
            this.grpSpecialAttrs.Controls.Add(this.txtAttr3);
            this.grpSpecialAttrs.Controls.Add(this.lblAttr3);
            this.grpSpecialAttrs.Controls.Add(this.txtAttr2);
            this.grpSpecialAttrs.Controls.Add(this.lblAttr2);
            this.grpSpecialAttrs.Controls.Add(this.txtAttr1);
            this.grpSpecialAttrs.Controls.Add(this.lblAttr1);
            this.grpSpecialAttrs.Location = new System.Drawing.Point(20, 180);
            this.grpSpecialAttrs.Name = "grpSpecialAttrs";
            this.grpSpecialAttrs.Size = new System.Drawing.Size(250, 150);
            this.grpSpecialAttrs.TabStop = false;
            this.grpSpecialAttrs.Text = "Specialized Attributes";

            // Special Attrs Layout
            this.lblAttr1.AutoSize = true;
            this.lblAttr1.Location = new System.Drawing.Point(10, 33);
            this.lblAttr1.Name = "lblAttr1";
            this.lblAttr1.Size = new System.Drawing.Size(43, 15);
            this.lblAttr1.Text = "Attr 1:";
            this.txtAttr1.Location = new System.Drawing.Point(130, 30);
            this.txtAttr1.Name = "txtAttr1";
            this.txtAttr1.Size = new System.Drawing.Size(100, 23);

            this.lblAttr2.AutoSize = true;
            this.lblAttr2.Location = new System.Drawing.Point(10, 73);
            this.lblAttr2.Name = "lblAttr2";
            this.lblAttr2.Size = new System.Drawing.Size(43, 15);
            this.lblAttr2.Text = "Attr 2:";
            this.txtAttr2.Location = new System.Drawing.Point(130, 70);
            this.txtAttr2.Name = "txtAttr2";
            this.txtAttr2.Size = new System.Drawing.Size(100, 23);

            this.lblAttr3.AutoSize = true;
            this.lblAttr3.Location = new System.Drawing.Point(10, 113);
            this.lblAttr3.Name = "lblAttr3";
            this.lblAttr3.Size = new System.Drawing.Size(43, 15);
            this.lblAttr3.Text = "Attr 3:";
            this.txtAttr3.Location = new System.Drawing.Point(130, 110);
            this.txtAttr3.Name = "txtAttr3";
            this.txtAttr3.Size = new System.Drawing.Size(100, 23);

            // btnAdd
            this.btnAdd.Location = new System.Drawing.Point(20, 340);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(250, 40);
            this.btnAdd.Text = "Instantiate Object";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);

            // cmbViewMode & lblViewMode
            this.lblViewMode.AutoSize = true;
            this.lblViewMode.Location = new System.Drawing.Point(300, 23);
            this.lblViewMode.Name = "lblViewMode";
            this.lblViewMode.Size = new System.Drawing.Size(95, 15);
            this.lblViewMode.Text = "Select View Mode:";

            this.cmbViewMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbViewMode.FormattingEnabled = true;
            this.cmbViewMode.Items.AddRange(new object[] { "Full Display ()", "Partial Display (Pass 1)", "Partial Display (Pass 2)" });
            this.cmbViewMode.Location = new System.Drawing.Point(410, 20);
            this.cmbViewMode.Name = "cmbViewMode";
            this.cmbViewMode.Size = new System.Drawing.Size(180, 23);
            this.cmbViewMode.SelectedIndexChanged += new System.EventHandler(this.cmbViewMode_SelectedIndexChanged);

            // lstCaves
            this.lstCaves.FormattingEnabled = true;
            this.lstCaves.ItemHeight = 15;
            this.lstCaves.Location = new System.Drawing.Point(300, 60);
            this.lstCaves.Name = "lstCaves";
            this.lstCaves.Size = new System.Drawing.Size(700, 319);

            // MainForm
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1020, 400);
            this.Controls.Add(this.lblViewMode);
            this.Controls.Add(this.cmbViewMode);
            this.Controls.Add(this.lstCaves);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.grpSpecialAttrs);
            this.Controls.Add(this.txtDepth);
            this.Controls.Add(this.lblDepth);
            this.Controls.Add(this.txtLocation);
            this.Controls.Add(this.lblLocation);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.lblType);
            this.Controls.Add(this.cmbCaveType);
            this.Name = "MainForm";
            this.Text = "Advanced Cave Tracker";
            this.grpSpecialAttrs.ResumeLayout(false);
            this.grpSpecialAttrs.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.ComboBox cmbCaveType;
        private System.Windows.Forms.Label lblType;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.TextBox txtLocation;
        private System.Windows.Forms.Label lblLocation;
        private System.Windows.Forms.TextBox txtDepth;
        private System.Windows.Forms.Label lblDepth;
        private System.Windows.Forms.GroupBox grpSpecialAttrs;
        private System.Windows.Forms.TextBox txtAttr3;
        private System.Windows.Forms.Label lblAttr3;
        private System.Windows.Forms.TextBox txtAttr2;
        private System.Windows.Forms.Label lblAttr2;
        private System.Windows.Forms.TextBox txtAttr1;
        private System.Windows.Forms.Label lblAttr1;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.ListBox lstCaves;
        private System.Windows.Forms.ComboBox cmbViewMode;
        private System.Windows.Forms.Label lblViewMode;
    }
}