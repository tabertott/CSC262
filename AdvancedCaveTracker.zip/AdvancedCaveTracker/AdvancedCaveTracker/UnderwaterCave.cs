﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdvancedCaveTracker
{
    public class UnderwaterCave : Cave, ICaveExploration
    {
        private int _waterTemp;
        private int _flowRate;
        private int _diveDepth;

        // Encapsulated properties with validation
        public int WaterTemp
        {
            get { return _waterTemp; }
            set { _waterTemp = (value >= -50 && value <= 100) ? value : 50; }
        }

        public int FlowRate
        {
            get { return _flowRate; }
            set { _flowRate = (value >= 0) ? value : 0; }
        }

        public int DiveDepth
        {
            get { return _diveDepth; }
            set { _diveDepth = (value >= 0) ? value : 0; }
        }

        // Constructor passes base variables to the parent class using 'base'
        public UnderwaterCave(string name, string location, int depth, int waterTemp, int flowRate, int diveDepth)
            : base(name, location, depth)
        {
            WaterTemp = waterTemp;
            FlowRate = flowRate;
            DiveDepth = diveDepth;
        }

        // Interface Implementation
        public string GetSpecializedGear()
        {
            return "Requires SCUBA gear, rebreather, and waterproof dive lights.";
        }

        // Overriding the base display method
        public override string Display()
        {
            return $"[Underwater] {Name} ({Location}) | Max Depth: {DepthInFeet}ft | Temp: {WaterTemp}F | Flow: {FlowRate} knots | Gear: {GetSpecializedGear()}";
        }

        public override string Display(int num)
        {
            if (num == 1) return $"[Underwater] Name: {Name}";
            if (num == 2) return $"[Underwater] Name: {Name} | Temp: {WaterTemp}F";
            return Display();
        }
    }
}