﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdvancedCaveTracker
{
    public class Cave
    {
        // Encapsulated Backing Fields
        private string _name;
        private string _location;
        private int _depthInFeet;

        // Property 1: Encapsulated Name
        public string Name
        {
            get { return _name; }
            set
            {
                // Validation: Prevent empty names
                if (!string.IsNullOrWhiteSpace(value))
                    _name = value;
                else
                    _name = "Unknown System";
            }
        }

        // Property 2: Encapsulated Location
        public string Location
        {
            get { return _location; }
            set
            {
                if (!string.IsNullOrWhiteSpace(value))
                    _location = value;
                else
                    _location = "Unknown Region";
            }
        }

        // Property 3: Encapsulated Depth
        public int DepthInFeet
        {
            get { return _depthInFeet; }
            set
            {
                // Validation: Depth cannot be negative
                if (value >= 0)
                    _depthInFeet = value;
                else
                    _depthInFeet = 0;
            }
        }

        public Cave(string name, string location, int depth)
        {
            Name = name;
            Location = location;
            DepthInFeet = depth;
        }

        // Polymorphism - Method 1: Display all data
        public virtual string Display()
        {
            return $"[Base Cave] {Name} | Location: {Location} | Depth: {DepthInFeet}ft";
        }

        // Polymorphism - Method 2: Display a subset of data based on an integer parameter
        public virtual string Display(int num)
        {
            if (num == 1)
            {
                return $"[Base Cave] Name: {Name}";
            }
            else if (num == 2)
            {
                return $"[Base Cave] Name: {Name} | Location: {Location}";
            }
            else
            {
                return Display(); // Default back to all attributes
            }
        }
    }
}