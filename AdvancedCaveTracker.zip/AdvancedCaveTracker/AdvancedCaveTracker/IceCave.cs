﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
 * File: IceCave.cs
 * Description: Inherits from Cave. Implements ICaveExploration interface.
 * Adds specific encapsulated fields for glacial environments.
 */

namespace AdvancedCaveTracker
{
    public class IceCave : Cave, ICaveExploration
    {
        private int _iceThickness;
        private string _glacierName;
        private int _internalTemp;

        // Encapsulated properties
        public int IceThickness
        {
            get { return _iceThickness; }
            set { _iceThickness = (value > 0) ? value : 1; }
        }

        public string GlacierName
        {
            get { return _glacierName; }
            set { _glacierName = !string.IsNullOrWhiteSpace(value) ? value : "Unnamed Glacier"; }
        }

        public int InternalTemp
        {
            get { return _internalTemp; }
            set { _internalTemp = (value <= 32) ? value : 32; } // Forces freezing temps
        }

        public IceCave(string name, string location, int depth, int iceThickness, string glacierName, int internalTemp)
            : base(name, location, depth)
        {
            IceThickness = iceThickness;
            GlacierName = glacierName;
            InternalTemp = internalTemp;
        }

        // Interface Implementation
        public string GetSpecializedGear()
        {
            return "Requires crampons, ice axes, and thermal survival suits.";
        }

        public override string Display()
        {
            return $"[Ice] {Name} in {GlacierName} ({Location}) | Thickness: {IceThickness}ft | Temp: {InternalTemp}F | Gear: {GetSpecializedGear()}";
        }

        public override string Display(int num)
        {
            if (num == 1) return $"[Ice] Name: {Name}";
            if (num == 2) return $"[Ice] Name: {Name} | Glacier: {GlacierName}";
            return Display();
        }
    }
}