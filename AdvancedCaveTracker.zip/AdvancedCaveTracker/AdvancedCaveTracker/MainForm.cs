﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace AdvancedCaveTracker
{
    public partial class MainForm : Form
    {
        private List<Cave> caveDatabase = new List<Cave>();

        public MainForm()
        {
            InitializeComponent();
            cmbCaveType.SelectedIndex = 0; // Default to Standard Cave
            cmbViewMode.SelectedIndex = 0; // Default to Full Display
        }

        // UX Feature: Changes input labels dynamically based on the type of cave selected
        private void cmbCaveType_SelectedIndexChanged(object sender, EventArgs e)
        {
            string type = cmbCaveType.SelectedItem.ToString();

            if (type == "Standard Cave")
            {
                grpSpecialAttrs.Enabled = false;
                lblAttr1.Text = "N/A";
                lblAttr2.Text = "N/A";
                lblAttr3.Text = "N/A";
            }
            else if (type == "Underwater Cave")
            {
                grpSpecialAttrs.Enabled = true;
                lblAttr1.Text = "Water Temp (F):";
                lblAttr2.Text = "Flow Rate (knots):";
                lblAttr3.Text = "Dive Depth (ft):";
            }
            else if (type == "Ice Cave")
            {
                grpSpecialAttrs.Enabled = true;
                lblAttr1.Text = "Ice Thickness (ft):";
                lblAttr2.Text = "Glacier Name:";
                lblAttr3.Text = "Internal Temp (F):";
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            // Base Input Validation
            int depth = 0;
            if (!int.TryParse(txtDepth.Text, out depth))
            {
                MessageBox.Show("Depth must be a valid number.", "Input Error");
                return;
            }

            string type = cmbCaveType.SelectedItem.ToString();

            // Object Instantiation based on selected Subclass
            if (type == "Standard Cave")
            {
                Cave newCave = new Cave(txtName.Text, txtLocation.Text, depth);
                caveDatabase.Add(newCave);
            }
            else if (type == "Underwater Cave")
            {
                int temp, flow, diveDepth;
                int.TryParse(txtAttr1.Text, out temp);
                int.TryParse(txtAttr2.Text, out flow);
                int.TryParse(txtAttr3.Text, out diveDepth);

                UnderwaterCave uCave = new UnderwaterCave(txtName.Text, txtLocation.Text, depth, temp, flow, diveDepth);
                caveDatabase.Add(uCave);
            }
            else if (type == "Ice Cave")
            {
                int thickness, intTemp;
                int.TryParse(txtAttr1.Text, out thickness);
                string glacier = txtAttr2.Text;
                int.TryParse(txtAttr3.Text, out intTemp);

                IceCave iCave = new IceCave(txtName.Text, txtLocation.Text, depth, thickness, glacier, intTemp);
                caveDatabase.Add(iCave);
            }

            RefreshList();
        }

        private void cmbViewMode_SelectedIndexChanged(object sender, EventArgs e)
        {
            RefreshList();
        }

        private void RefreshList()
        {
            lstCaves.Items.Clear();
            string viewMode = cmbViewMode.SelectedItem?.ToString() ?? "Full Display ()";

            foreach (Cave c in caveDatabase)
            {
                if (viewMode == "Partial Display (Pass 1)")
                {
                    lstCaves.Items.Add(c.Display(1));
                }
                else if (viewMode == "Partial Display (Pass 2)")
                {
                    lstCaves.Items.Add(c.Display(2));
                }
                else
                {
                    lstCaves.Items.Add(c.Display());
                }
            }
        }
    }
}