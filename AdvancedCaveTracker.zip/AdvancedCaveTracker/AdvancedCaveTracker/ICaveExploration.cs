﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdvancedCaveTracker 
{ 
    public interface ICaveExploration 
    { // Interface method definition.
        string GetSpecializedGear(); 
    } 
}