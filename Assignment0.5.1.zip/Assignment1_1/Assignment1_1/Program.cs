﻿using System;
using System.Windows.Forms;

namespace Assignment1_1
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Initializes the application with your newly named form
            Application.Run(new Assignment1_1());
        }
    }
}