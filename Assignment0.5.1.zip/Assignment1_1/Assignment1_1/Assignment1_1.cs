﻿using System;
using System.Diagnostics;
using System.Windows.Forms;

namespace Assignment1_1
{
    public partial class Assignment1_1 : Form
    {
        public Assignment1_1()
        {
            InitializeComponent();
        }

        // Function 1: Evaluates if a person meets the legal voting age threshold.
        private bool IsEligibleToVote(string ageInput)
        {
            if (int.TryParse(ageInput, out int age))
            {
                return age >= 18;
            }
            return false;
        }

        // Function 2: Verifies the structural integrity of a password based on length.
        private bool IsValidPasswordLength(string passwordInput)
        {
            if (string.IsNullOrEmpty(passwordInput))
            {
                return false;
            }
            return passwordInput.Length >= 8;
        }

        // Event Handler for the Age Check Button
        private void btnCheckAge_Click(object sender, EventArgs e)
        {
            bool result = IsEligibleToVote(txtAge.Text);

            Debug.Assert(result == true, "Assertion Failed: User is not eligible to vote, or input was invalid.");
            MessageBox.Show($"Eligible to vote: {result}", "Age Result");
        }

        // Event Handler for the Password Check Button
        private void btnCheckPassword_Click(object sender, EventArgs e)
        {
            bool result = IsValidPasswordLength(txtPassword.Text);

            Debug.Assert(result == true, "Assertion Failed: Password is too short.");
            MessageBox.Show($"Valid password length: {result}", "Password Result");
        }
    }
}