﻿namespace Assignment1_1
{
    partial class Assignment1_1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblAge = new System.Windows.Forms.Label();
            this.txtAge = new System.Windows.Forms.TextBox();
            this.btnCheckAge = new System.Windows.Forms.Button();
            this.lblPassword = new System.Windows.Forms.Label();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.btnCheckPassword = new System.Windows.Forms.Button();
            this.SuspendLayout();

            // lblAge
            this.lblAge.AutoSize = true;
            this.lblAge.Location = new System.Drawing.Point(30, 30);
            this.lblAge.Name = "lblAge";
            this.lblAge.Size = new System.Drawing.Size(100, 15);
            this.lblAge.TabIndex = 0;
            this.lblAge.Text = "Enter your age:";

            // txtAge
            this.txtAge.Location = new System.Drawing.Point(30, 50);
            this.txtAge.Name = "txtAge";
            this.txtAge.Size = new System.Drawing.Size(150, 23);
            this.txtAge.TabIndex = 1;

            // btnCheckAge
            this.btnCheckAge.Location = new System.Drawing.Point(30, 80);
            this.btnCheckAge.Name = "btnCheckAge";
            this.btnCheckAge.Size = new System.Drawing.Size(150, 30);
            this.btnCheckAge.TabIndex = 2;
            this.btnCheckAge.Text = "Check Age Eligibility";
            this.btnCheckAge.UseVisualStyleBackColor = true;
            this.btnCheckAge.Click += new System.EventHandler(this.btnCheckAge_Click);

            // lblPassword
            this.lblPassword.AutoSize = true;
            this.lblPassword.Location = new System.Drawing.Point(30, 140);
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.Size = new System.Drawing.Size(180, 15);
            this.lblPassword.TabIndex = 3;
            this.lblPassword.Text = "Enter a password (min 8 chars):";

            // txtPassword
            this.txtPassword.Location = new System.Drawing.Point(30, 160);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(150, 23);
            this.txtPassword.TabIndex = 4;
            this.txtPassword.UseSystemPasswordChar = true;

            // btnCheckPassword
            this.btnCheckPassword.Location = new System.Drawing.Point(30, 190);
            this.btnCheckPassword.Name = "btnCheckPassword";
            this.btnCheckPassword.Size = new System.Drawing.Size(150, 30);
            this.btnCheckPassword.TabIndex = 5;
            this.btnCheckPassword.Text = "Verify Password Length";
            this.btnCheckPassword.UseVisualStyleBackColor = true;
            this.btnCheckPassword.Click += new System.EventHandler(this.btnCheckPassword_Click);

            // Assignment1_1 Form
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(250, 260);
            this.Controls.Add(this.btnCheckPassword);
            this.Controls.Add(this.txtPassword);
            this.Controls.Add(this.lblPassword);
            this.Controls.Add(this.btnCheckAge);
            this.Controls.Add(this.txtAge);
            this.Controls.Add(this.lblAge);
            this.Name = "Assignment1_1";
            this.Text = "Unit Testing UI";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label lblAge;
        private System.Windows.Forms.TextBox txtAge;
        private System.Windows.Forms.Button btnCheckAge;
        private System.Windows.Forms.Label lblPassword;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Button btnCheckPassword;
    }
}