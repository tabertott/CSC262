﻿using System;
using System.Diagnostics;
using System.Windows.Forms;

namespace PerformanceApp
{
    public partial class PerformanceTesting : Form
    {
        // Instantiate a single Random object to be used across the application
        private Random randomGenerator = new Random();

        public PerformanceTesting()
        {
            InitializeComponent();
        }

        private void btnRunTest_Click(object sender, EventArgs e)
        {
            // Clear previous results before running a new test
            lblGenerationTime.Text = "Generation Time: ";
            lblSortTime.Text = "Sort Time: ";

            // Validate that the input is a valid integer and falls strictly within the required boundaries
            if (int.TryParse(txtArraySize.Text, out int arraySize) && arraySize > 0 && arraySize < 100000)
            {
                RunPerformanceTest(arraySize);
            }
            else
            {
                // Prevent application crash and guide the user back to valid parameters
                MessageBox.Show("Please enter a valid whole number greater than 0 and less than 100,000.",
                                "Invalid Input",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);
            }
        }

        private void RunPerformanceTest(int size)
        {
            int[] numbers = new int[size];
            Stopwatch timer = new Stopwatch();

            // Measure Phase 1: Data Generation
            timer.Start();
            for (int i = 0; i < size; i++)
            {
                // Fill the array with random numbers between 1 and 1,000,000
                numbers[i] = randomGenerator.Next(1, 1000001);
            }
            timer.Stop();

            // Record the elapsed time for generation
            lblGenerationTime.Text = $"Generation Time: {timer.Elapsed.TotalMilliseconds} ms";

            // Reset the timer for the sorting phase
            timer.Reset();

            // Measure Phase 2: Array Sorting
            timer.Start();
            Array.Sort(numbers);
            timer.Stop();

            // Record the elapsed time for sorting
            lblSortTime.Text = $"Sort Time: {timer.Elapsed.TotalMilliseconds} ms";
        }
    }
}