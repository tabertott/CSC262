﻿namespace PerformanceApp
{
    partial class PerformanceTesting
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblInstruction = new System.Windows.Forms.Label();
            this.txtArraySize = new System.Windows.Forms.TextBox();
            this.btnRunTest = new System.Windows.Forms.Button();
            this.lblGenerationTime = new System.Windows.Forms.Label();
            this.lblSortTime = new System.Windows.Forms.Label();
            this.SuspendLayout();

            // lblInstruction
            this.lblInstruction.AutoSize = true;
            this.lblInstruction.Location = new System.Drawing.Point(30, 30);
            this.lblInstruction.Name = "lblInstruction";
            this.lblInstruction.Size = new System.Drawing.Size(220, 15);
            this.lblInstruction.TabIndex = 0;
            this.lblInstruction.Text = "Enter Array Size (Greater than 0, Less than 100,000):";

            // txtArraySize
            this.txtArraySize.Location = new System.Drawing.Point(30, 50);
            this.txtArraySize.Name = "txtArraySize";
            this.txtArraySize.Size = new System.Drawing.Size(150, 23);
            this.txtArraySize.TabIndex = 1;

            // btnRunTest
            this.btnRunTest.Location = new System.Drawing.Point(30, 80);
            this.btnRunTest.Name = "btnRunTest";
            this.btnRunTest.Size = new System.Drawing.Size(150, 30);
            this.btnRunTest.TabIndex = 2;
            this.btnRunTest.Text = "Run Performance Test";
            this.btnRunTest.UseVisualStyleBackColor = true;
            this.btnRunTest.Click += new System.EventHandler(this.btnRunTest_Click);

            // lblGenerationTime
            this.lblGenerationTime.AutoSize = true;
            this.lblGenerationTime.Location = new System.Drawing.Point(30, 130);
            this.lblGenerationTime.Name = "lblGenerationTime";
            this.lblGenerationTime.Size = new System.Drawing.Size(100, 15);
            this.lblGenerationTime.TabIndex = 3;
            this.lblGenerationTime.Text = "Generation Time: ";

            // lblSortTime
            this.lblSortTime.AutoSize = true;
            this.lblSortTime.Location = new System.Drawing.Point(30, 160);
            this.lblSortTime.Name = "lblSortTime";
            this.lblSortTime.Size = new System.Drawing.Size(65, 15);
            this.lblSortTime.TabIndex = 4;
            this.lblSortTime.Text = "Sort Time: ";

            // PerformanceTesting Form
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(350, 220);
            this.Controls.Add(this.lblSortTime);
            this.Controls.Add(this.lblGenerationTime);
            this.Controls.Add(this.btnRunTest);
            this.Controls.Add(this.txtArraySize);
            this.Controls.Add(this.lblInstruction);
            this.Name = "PerformanceTesting";
            this.Text = "Performance Testing";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label lblInstruction;
        private System.Windows.Forms.TextBox txtArraySize;
        private System.Windows.Forms.Button btnRunTest;
        private System.Windows.Forms.Label lblGenerationTime;
        private System.Windows.Forms.Label lblSortTime;
    }
}